Im Dossier 01.1 finden Sie die txt-Dateien mit den Gemeinden ab dem 1. Januar 1960, dagegen finden Sie im Dossier 01.2 die Gemeinden ab dem 12. September 1848.

Dans le dossier 01.1 vous trouverez les fichiers txt avec les communes � partir du 1er janvier 1960, tandis que dans le dossier 01.2 vous trouverez les communes � partir du 12 septembre 1848.

Nella cartella 01.1 troverete i file dell�omonima versione dello standard eCH-0071 con i Comuni a partire dal 1� gennaio 1960, mentre nella cartella 01.2 troverete i Comuni a partire dal 12 settembre 1848.